LEGION CONTROL - Phase 1 (build on phone via GitHub)

1) Create a free account on github.com and a new repository (any name).
2) Upload ALL files of this folder to it, including the hidden folder .github (keep the folder structure).
3) Open the Actions tab, open the latest "build" run, wait for the green check.
4) At the bottom, download the artifact "legion-control-jar". Unzip it: it contains the mod jar.
5) Put the jar + Fabric API jar in your mods folder.
6) If the run is red, open it, copy the error text, and send it to Claude.
In game: press R for the menu, or /legion spawn 20
