package com.legion.client;

import com.legion.net.ActionPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

public class LegionScreen extends Screen {
    private enum Page { MAIN, BOTS, MOVE }

    private static final int MAX = 300;
    private Page page = Page.MAIN;
    private TextFieldWidget amountField;

    public LegionScreen() {
        super(Text.literal("Legion Control"));
    }

    @Override
    public boolean shouldPause() {
        return false; // keep the world running while the menu is open
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        int top = this.height / 2 - 60;
        int bw = 200;
        int bx = cx - bw / 2;

        switch (page) {
            case MAIN -> {
                btn("Spawn / Remove Bots", bx, top, bw, () -> go(Page.BOTS));
                btn("Movement", bx, top + 24, bw, () -> go(Page.MOVE));
                btn("Close", bx, top + 60, bw, this::close);
            }
            case BOTS -> {
                amountField = new TextFieldWidget(this.textRenderer, cx - 50, top, 100, 20, Text.literal("Amount"));
                amountField.setText(String.valueOf(ClientState.amount));
                amountField.setChangedListener(s -> {
                    try {
                        ClientState.amount = clamp(Integer.parseInt(s.trim()));
                    } catch (NumberFormatException ignored) {}
                });
                this.addDrawableChild(amountField);

                int[] deltas = {-100, -10, -1, 1, 10, 100};
                int x0 = cx - 101;
                for (int i = 0; i < deltas.length; i++) {
                    final int d = deltas[i];
                    btn((d > 0 ? "+" : "") + d, x0 + i * 34, top + 24, 32, () -> {
                        ClientState.amount = clamp(ClientState.amount + d);
                        amountField.setText(String.valueOf(ClientState.amount));
                    });
                }
                btn("Spawn", bx, top + 52, bw, () -> send(ActionPayload.SPAWN, ClientState.amount));
                btn("Remove (this many)", bx, top + 76, bw, () -> send(ActionPayload.REMOVE_COUNT, ClientState.amount));
                btn("Remove All", bx, top + 100, bw, () -> send(ActionPayload.REMOVE_ALL, 1));
                btn("Back", bx, top + 130, bw, () -> go(Page.MAIN));
            }
            case MOVE -> {
                btn("Follow me", bx, top, bw, () -> send(ActionPayload.FOLLOW, 1));
                btn("Stop", bx, top + 24, bw, () -> send(ActionPayload.STOP, 1));
                btn("Walk (in my facing direction)", bx, top + 48, bw, () -> send(ActionPayload.WALK, 1));
                btn("Idle", bx, top + 72, bw, () -> send(ActionPayload.IDLE, 1));
                btn("Jump", bx, top + 96, bw, () -> send(ActionPayload.JUMP, 1));
                btn("Back", bx, top + 126, bw, () -> go(Page.MAIN));
            }
        }
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        int cx = this.width / 2;
        int top = this.height / 2 - 60;
        ctx.drawCenteredTextWithShadow(this.textRenderer, this.title, cx, top - 34, 0xFFFFFFFF);
        String status = "Your bots: " + ClientState.count
                + (ClientState.queued > 0 ? "   (spawning: " + ClientState.queued + ")" : "");
        ctx.drawCenteredTextWithShadow(this.textRenderer, Text.literal(status), cx, top - 20, 0xFFAAAAAA);
    }

    private ButtonWidget btn(String label, int x, int y, int w, Runnable action) {
        return this.addDrawableChild(ButtonWidget.builder(Text.literal(label), b -> action.run())
                .dimensions(x, y, w, 20).build());
    }

    private void go(Page p) {
        this.page = p;
        this.clearAndInit();
    }

    private static int clamp(int v) {
        return Math.max(1, Math.min(MAX, v));
    }

    private static void send(int action, int amount) {
        ClientPlayNetworking.send(new ActionPayload(action, amount));
    }
}
