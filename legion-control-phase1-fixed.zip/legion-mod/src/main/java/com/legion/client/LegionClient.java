package com.legion.client;

import com.legion.net.StatusPayload;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public class LegionClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        KeyBinding open = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.legion.open",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_R,
                KeyBinding.Category.create(Identifier.of("legion", "main"))));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (open.wasPressed()) {
                if (client.currentScreen == null && client.player != null) {
                    client.setScreen(new LegionScreen());
                }
            }
        });

        ClientPlayNetworking.registerGlobalReceiver(StatusPayload.ID, (payload, context) -> {
            ClientState.count = payload.count();
            ClientState.queued = payload.queued();
        });
    }
}
