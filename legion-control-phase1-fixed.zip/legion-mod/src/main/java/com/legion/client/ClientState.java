package com.legion.client;

public final class ClientState {
    public static int count = 0;
    public static int queued = 0;
    public static int amount = 10;
    private ClientState() {}
}
