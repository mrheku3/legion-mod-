package com.legion;

import io.netty.channel.ChannelFutureListener;
import io.netty.channel.embedded.EmbeddedChannel;
import net.minecraft.network.ClientConnection;
import net.minecraft.network.NetworkSide;
import net.minecraft.network.listener.PacketListener;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.state.NetworkState;

/** A network connection that goes nowhere. Bots are server-side only, so nothing is ever sent. */
public class FakeConnection extends ClientConnection {
    private final EmbeddedChannel ch;

    public FakeConnection() {
        super(NetworkSide.SERVERBOUND);
        this.ch = new EmbeddedChannel(this);
    }

    // Intentionally no @Override on these: they swallow all outgoing traffic.
    public void send(Packet<?> packet) {}
    public void send(Packet<?> packet, ChannelFutureListener listener) {}
    public void send(Packet<?> packet, ChannelFutureListener listener, boolean flush) {}
    public void tick() {}
    public void disableAutoRead() {}
    public void handleDisconnection() {}
    public <T extends PacketListener> void transitionInbound(NetworkState<T> state, T listener) {}
    @Override
    public void transitionOutbound(NetworkState<?> state) {}

    /** Prevents memory growth from anything that still reached the embedded channel. */
    public void drain() {
        ch.outboundMessages().clear();
        ch.inboundMessages().clear();
    }
}
