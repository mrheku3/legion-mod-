package com.legion;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.context.CommandContext;
import net.minecraft.command.argument.Vec3ArgumentType;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.math.Vec3d;

public final class LegionCommands {
    private LegionCommands() {}

    public static void register(CommandDispatcher<ServerCommandSource> d) {
        d.register(CommandManager.literal("legion")
                .then(CommandManager.literal("spawn")
                        .then(CommandManager.argument("count", IntegerArgumentType.integer(1, LegionManager.MAX_BOTS))
                                .executes(ctx -> {
                                    ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
                                    return reply(ctx, LegionManager.spawn(p, IntegerArgumentType.getInteger(ctx, "count"),
                                            p.getX(), p.getY(), p.getZ()));
                                })
                                .then(CommandManager.argument("pos", Vec3ArgumentType.vec3())
                                        .executes(ctx -> {
                                            ServerPlayerEntity p = ctx.getSource().getPlayerOrThrow();
                                            Vec3d v = Vec3ArgumentType.getVec3(ctx, "pos");
                                            return reply(ctx, LegionManager.spawn(p, IntegerArgumentType.getInteger(ctx, "count"),
                                                    v.x, v.y, v.z));
                                        }))))
                .then(CommandManager.literal("remove")
                        .then(CommandManager.literal("all")
                                .executes(ctx -> reply(ctx, LegionManager.removeAll(ctx.getSource().getPlayerOrThrow().getUuid()))))
                        .then(CommandManager.argument("count", IntegerArgumentType.integer(1, LegionManager.MAX_BOTS))
                                .executes(ctx -> reply(ctx, LegionManager.removeCount(
                                        ctx.getSource().getPlayerOrThrow().getUuid(), IntegerArgumentType.getInteger(ctx, "count"))))))
                .then(CommandManager.literal("count")
                        .executes(ctx -> reply(ctx, LegionManager.count(ctx.getSource().getPlayerOrThrow().getUuid()))))
                .then(CommandManager.literal("follow")
                        .executes(ctx -> reply(ctx, LegionManager.setMode(ctx.getSource().getPlayerOrThrow(), BotPlayer.Mode.FOLLOW))))
                .then(CommandManager.literal("walk")
                        .executes(ctx -> reply(ctx, LegionManager.setMode(ctx.getSource().getPlayerOrThrow(), BotPlayer.Mode.WALK))))
                .then(CommandManager.literal("stop")
                        .executes(ctx -> reply(ctx, LegionManager.setMode(ctx.getSource().getPlayerOrThrow(), BotPlayer.Mode.IDLE))))
                .then(CommandManager.literal("idle")
                        .executes(ctx -> reply(ctx, LegionManager.setMode(ctx.getSource().getPlayerOrThrow(), BotPlayer.Mode.IDLE))))
                .then(CommandManager.literal("jump")
                        .executes(ctx -> reply(ctx, LegionManager.jump(ctx.getSource().getPlayerOrThrow().getUuid()))))
        );
    }

    private static int reply(CommandContext<ServerCommandSource> ctx, String msg) {
        ctx.getSource().sendFeedback(() -> Text.literal(msg), false);
        return 1;
    }
}
