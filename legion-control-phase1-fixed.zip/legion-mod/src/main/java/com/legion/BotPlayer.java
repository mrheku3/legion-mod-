package com.legion;

import com.mojang.authlib.GameProfile;
import net.minecraft.network.packet.c2s.common.SyncedClientOptions;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;

import java.util.UUID;

/** A real server-side player entity with no client behind it. */
public class BotPlayer extends ServerPlayerEntity {
    public enum Mode { IDLE, FOLLOW, WALK }

    public final UUID ownerId;
    public final int slot;
    public Mode mode = Mode.IDLE;
    public float walkYaw;
    public FakeConnection fakeConn;

    public BotPlayer(MinecraftServer server, ServerWorld world, GameProfile profile, UUID ownerId, int slot) {
        super(server, world, profile, SyncedClientOptions.createDefault());
        this.ownerId = ownerId;
        this.slot = slot;
    }

    @Override
    public void tick() {
        think();
        if (this.age % 10 == 0) {
            try {
                LegionUtil.world(this).getChunkManager().updatePosition(this);
            } catch (Exception ignored) {}
            if (fakeConn != null) fakeConn.drain();
        }
        try {
            super.tick();
            this.playerTick();
        } catch (NullPointerException ignored) {
            // fake connection has no real network handler state
        }
    }

    public void doJump() {
        if (this.isOnGround()) this.jump();
    }

    private void think() {
        this.forwardSpeed = 0f;
        this.sidewaysSpeed = 0f;
        switch (mode) {
            case IDLE -> this.setSprinting(false);
            case WALK -> {
                face(walkYaw);
                this.forwardSpeed = 1f;
                this.setSprinting(false);
                hop();
            }
            case FOLLOW -> {
                MinecraftServer srv = LegionManager.server();
                ServerPlayerEntity owner = srv == null ? null : srv.getPlayerManager().getPlayer(ownerId);
                if (owner == null || LegionUtil.world(owner) != LegionUtil.world(this)) {
                    this.setSprinting(false);
                    return;
                }
                double rad = 2.5 + 1.2 * Math.sqrt(slot);
                double ang = slot * 2.399963;
                double tx = owner.getX() + Math.cos(ang) * rad;
                double tz = owner.getZ() + Math.sin(ang) * rad;
                double dx = tx - this.getX();
                double dz = tz - this.getZ();
                double d2 = dx * dx + dz * dz;
                if (d2 > 48 * 48) {
                    this.refreshPositionAndAngles(tx, owner.getY(), tz, this.getYaw(), 0f);
                    return;
                }
                if (d2 > 1.0) {
                    face((float) (Math.atan2(dz, dx) * 180.0 / Math.PI) - 90f);
                    this.forwardSpeed = 1f;
                    this.setSprinting(d2 > 64);
                    hop();
                } else {
                    this.setSprinting(false);
                }
            }
        }
    }

    private void face(float yaw) {
        this.setYaw(yaw);
        this.setHeadYaw(yaw);
        this.setBodyYaw(yaw);
        this.setPitch(0f);
    }

    private void hop() {
        if ((this.horizontalCollision && this.isOnGround()) || this.isTouchingWater()) this.jump();
    }
}
