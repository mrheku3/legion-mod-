package com.legion;

import com.legion.net.StatusPayload;
import com.mojang.authlib.GameProfile;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.PlayerManager;
import net.minecraft.server.network.ConnectedClientData;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.Box;
import net.minecraft.world.GameMode;

import java.nio.charset.StandardCharsets;
import java.util.*;

public final class LegionManager {
    public static final int MAX_BOTS = 300;
    private static final int SPAWNS_PER_TICK = 2;

    private static final String[] NAMES = {
            "Atlas", "Orion", "Cyrus", "Dante", "Kratos", "Ajax", "Brutus", "Cato", "Draco", "Erebus",
            "Fenrir", "Gaius", "Hector", "Icarus", "Jarvik", "Khan", "Leonid", "Marcus", "Nero", "Odin",
            "Perseus", "Quintus", "Rex", "Spartan", "Titus", "Ulric", "Valen", "Wolf", "Xerxes", "Yorick",
            "Zephyr", "Axel", "Bjorn", "Conan", "Dagger", "Ember", "Falcon", "Gryph", "Hawk", "Ivor",
            "Jax", "Knox", "Lance", "Magnus", "Nox", "Onyx", "Pike", "Quill", "Raven", "Storm"
    };

    private record SpawnRequest(UUID owner, ServerWorld world, double cx, double cy, double cz,
                                int ring, int slot, float yaw) {}

    private static MinecraftServer server;
    private static final Map<UUID, BotPlayer> BOTS = new LinkedHashMap<>();
    private static final ArrayDeque<SpawnRequest> QUEUE = new ArrayDeque<>();
    private static int nameCounter = 0;

    private LegionManager() {}

    public static MinecraftServer server() { return server; }
    public static void setServer(MinecraftServer s) { server = s; }

    // ---------- queries ----------
    public static int countFor(UUID owner) {
        int n = 0;
        for (BotPlayer b : BOTS.values()) if (b.ownerId.equals(owner)) n++;
        return n;
    }

    public static int queuedFor(UUID owner) {
        int n = 0;
        for (SpawnRequest r : QUEUE) if (r.owner().equals(owner)) n++;
        return n;
    }

    // ---------- actions (each returns a feedback message) ----------
    public static String spawn(ServerPlayerEntity owner, int count, double cx, double cy, double cz) {
        int total = BOTS.size() + QUEUE.size();
        int allowed = Math.min(count, MAX_BOTS - total);
        if (allowed <= 0) return "Bot limit reached (" + MAX_BOTS + ").";
        int baseSlot = countFor(owner.getUuid()) + queuedFor(owner.getUuid());
        ServerWorld w = LegionUtil.world(owner);
        for (int i = 0; i < allowed; i++) {
            QUEUE.add(new SpawnRequest(owner.getUuid(), w, cx, cy, cz, i, baseSlot + i, owner.getYaw()));
        }
        return "Spawning " + allowed + " bots gradually" + (allowed < count ? " (limited by max " + MAX_BOTS + ")" : "") + ".";
    }

    public static String removeAll(UUID owner) {
        QUEUE.removeIf(r -> r.owner().equals(owner));
        List<BotPlayer> mine = owned(owner);
        for (BotPlayer b : mine) removeBot(b);
        return "Removed " + mine.size() + " bots.";
    }

    public static String removeCount(UUID owner, int n) {
        List<BotPlayer> mine = owned(owner);
        int removed = 0;
        for (int i = mine.size() - 1; i >= 0 && removed < n; i--, removed++) removeBot(mine.get(i));
        return "Removed " + removed + " bots.";
    }

    public static String setMode(ServerPlayerEntity owner, BotPlayer.Mode mode) {
        List<BotPlayer> mine = owned(owner.getUuid());
        for (BotPlayer b : mine) {
            b.mode = mode;
            if (mode == BotPlayer.Mode.WALK) b.walkYaw = owner.getYaw();
        }
        return mine.size() + " bots: " + mode.name().toLowerCase();
    }

    public static String jump(UUID owner) {
        List<BotPlayer> mine = owned(owner);
        for (BotPlayer b : mine) b.doJump();
        return mine.size() + " bots jumped.";
    }

    public static String count(UUID owner) {
        return "You have " + countFor(owner) + " bots (" + queuedFor(owner) + " still spawning).";
    }

    // ---------- lifecycle ----------
    public static void shutdown() {
        QUEUE.clear();
        for (BotPlayer b : new ArrayList<>(BOTS.values())) removeBot(b);
        BOTS.clear();
    }

    public static void tick(MinecraftServer s) {
        if (server == null) server = s;

        // drop dead / vanished bots
        List<BotPlayer> gone = null;
        for (BotPlayer b : BOTS.values()) {
            if (b.isRemoved() || !b.isAlive()) {
                if (gone == null) gone = new ArrayList<>();
                gone.add(b);
            }
        }
        if (gone != null) for (BotPlayer b : gone) removeBot(b);

        // gradual spawning
        int n = 0;
        while (n < SPAWNS_PER_TICK && !QUEUE.isEmpty()) {
            SpawnRequest r = QUEUE.poll();
            try {
                spawnOne(r);
            } catch (Exception e) {
                LegionMod.LOGGER.error("Bot spawn failed", e);
                ServerPlayerEntity o = s.getPlayerManager().getPlayer(r.owner());
                if (o != null) o.sendMessage(net.minecraft.text.Text.literal(
                        "Legion: spawn failed (" + e.getClass().getSimpleName() + "), see log. Queue cleared."), false);
                QUEUE.clear();
                break;
            }
            n++;
        }

        // status to GUI clients
        if (s.getTicks() % 10 == 0) {
            for (ServerPlayerEntity p : new ArrayList<>(s.getPlayerManager().getPlayerList())) {
                if (p instanceof BotPlayer) continue;
                if (ServerPlayNetworking.canSend(p, StatusPayload.ID)) {
                    ServerPlayNetworking.send(p, new StatusPayload(countFor(p.getUuid()), queuedFor(p.getUuid())));
                }
            }
        }
    }

    // ---------- internals ----------
    private static List<BotPlayer> owned(UUID owner) {
        List<BotPlayer> list = new ArrayList<>();
        for (BotPlayer b : BOTS.values()) if (b.ownerId.equals(owner)) list.add(b);
        return list;
    }

    private static void removeBot(BotPlayer b) {
        BOTS.remove(b.getUuid());
        if (!b.isRemoved()) {
            PlayerManager pm = server.getPlayerManager();
            pm.remove(b);
        }
    }

    private static void spawnOne(SpawnRequest r) {
        double rad = 1.5 + 1.1 * Math.sqrt(r.ring());
        double ang = r.ring() * 2.399963;
        double x = r.cx() + Math.cos(ang) * rad;
        double z = r.cz() + Math.sin(ang) * rad;
        double y = safeY(r.world(), x, r.cy(), z);

        String name = nextName();
        UUID id = UUID.nameUUIDFromBytes(("LegionBot:" + name).getBytes(StandardCharsets.UTF_8));
        GameProfile profile = new GameProfile(id, name);

        BotPlayer bot = new BotPlayer(server, r.world(), profile, r.owner(), r.slot());
        FakeConnection conn = new FakeConnection();
        bot.fakeConn = conn;
        server.getPlayerManager().onPlayerConnect(conn, bot, ConnectedClientData.createDefault(profile, false));

        bot.refreshPositionAndAngles(x, y, z, r.yaw(), 0f);
        bot.changeGameMode(GameMode.SURVIVAL);
        bot.getInventory().clear();
        bot.setHealth(bot.getMaxHealth());
        BOTS.put(bot.getUuid(), bot);
    }

    private static double safeY(ServerWorld w, double x, double y, double z) {
        for (int dy : new int[]{0, 1, 2, 3, -1, -2}) {
            Box b = new Box(x - 0.3, y + dy, z - 0.3, x + 0.3, y + dy + 1.8, z + 0.3);
            if (w.isSpaceEmpty(b)) return y + dy;
        }
        return y;
    }

    private static String nextName() {
        for (int tries = 0; tries < 2000; tries++) {
            int i = nameCounter++;
            String base = NAMES[i % NAMES.length];
            int round = i / NAMES.length;
            String name = round == 0 ? base : base + round;
            if (name.length() > 16) name = name.substring(0, 16);
            if (server.getPlayerManager().getPlayer(name) == null) return name;
        }
        return "Legion" + (int) (Math.random() * 99999);
    }
}
