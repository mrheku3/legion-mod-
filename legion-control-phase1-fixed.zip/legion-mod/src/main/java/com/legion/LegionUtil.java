package com.legion;

import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;

public final class LegionUtil {
    private LegionUtil() {}

    /** If this line fails to compile, change getEntityWorld() to getWorld() (mapping name differs by build). */
    public static ServerWorld world(ServerPlayerEntity p) {
        return (ServerWorld) p.getEntityWorld();
    }
}
