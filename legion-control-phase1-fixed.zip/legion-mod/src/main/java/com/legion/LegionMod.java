package com.legion;

import com.legion.net.LegionNet;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LegionMod implements ModInitializer {
    public static final String MOD_ID = "legion";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        LegionNet.register();
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                LegionCommands.register(dispatcher));
        ServerLifecycleEvents.SERVER_STARTED.register(LegionManager::setServer);
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> LegionManager.shutdown());
        ServerTickEvents.END_SERVER_TICK.register(LegionManager::tick);
        LOGGER.info("Legion Control loaded");
    }
}
