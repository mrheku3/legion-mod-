package com.legion.net;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/** Client -> server: a GUI button was pressed. */
public record ActionPayload(int action, int amount) implements CustomPayload {
    public static final int SPAWN = 0, REMOVE_COUNT = 1, REMOVE_ALL = 2,
            FOLLOW = 3, STOP = 4, WALK = 5, IDLE = 6, JUMP = 7;

    public static final CustomPayload.Id<ActionPayload> ID = new CustomPayload.Id<>(Identifier.of("legion", "action"));
    public static final PacketCodec<RegistryByteBuf, ActionPayload> CODEC = PacketCodec.tuple(
            PacketCodecs.VAR_INT, ActionPayload::action,
            PacketCodecs.VAR_INT, ActionPayload::amount,
            ActionPayload::new);

    @Override
    public CustomPayload.Id<? extends CustomPayload> getId() { return ID; }
}
