package com.legion.net;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/** Server -> client: how many bots the player has, and how many are still spawning. */
public record StatusPayload(int count, int queued) implements CustomPayload {
    public static final CustomPayload.Id<StatusPayload> ID = new CustomPayload.Id<>(Identifier.of("legion", "status"));
    public static final PacketCodec<RegistryByteBuf, StatusPayload> CODEC = PacketCodec.tuple(
            PacketCodecs.VAR_INT, StatusPayload::count,
            PacketCodecs.VAR_INT, StatusPayload::queued,
            StatusPayload::new);

    @Override
    public CustomPayload.Id<? extends CustomPayload> getId() { return ID; }
}
