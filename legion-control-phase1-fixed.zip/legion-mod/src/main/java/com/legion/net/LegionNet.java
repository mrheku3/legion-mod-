package com.legion.net;

import com.legion.BotPlayer;
import com.legion.LegionManager;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

public final class LegionNet {
    private LegionNet() {}

    public static void register() {
        PayloadTypeRegistry.playC2S().register(ActionPayload.ID, ActionPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(StatusPayload.ID, StatusPayload.CODEC);

        ServerPlayNetworking.registerGlobalReceiver(ActionPayload.ID, (payload, context) -> {
            ServerPlayerEntity p = context.player();
            if (p instanceof BotPlayer) return;
            int amount = Math.max(1, Math.min(LegionManager.MAX_BOTS, payload.amount()));
            String msg = switch (payload.action()) {
                case ActionPayload.SPAWN -> LegionManager.spawn(p, amount, p.getX(), p.getY(), p.getZ());
                case ActionPayload.REMOVE_COUNT -> LegionManager.removeCount(p.getUuid(), amount);
                case ActionPayload.REMOVE_ALL -> LegionManager.removeAll(p.getUuid());
                case ActionPayload.FOLLOW -> LegionManager.setMode(p, BotPlayer.Mode.FOLLOW);
                case ActionPayload.STOP, ActionPayload.IDLE -> LegionManager.setMode(p, BotPlayer.Mode.IDLE);
                case ActionPayload.WALK -> LegionManager.setMode(p, BotPlayer.Mode.WALK);
                case ActionPayload.JUMP -> LegionManager.jump(p.getUuid());
                default -> null;
            };
            if (msg != null) p.sendMessage(Text.literal(msg), true);
        });
    }
}
